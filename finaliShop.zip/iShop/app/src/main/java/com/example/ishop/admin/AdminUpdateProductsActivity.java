package com.example.ishop.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.ishop.R;
import com.example.ishop.seller.SellerCategoryActivity;
import com.example.ishop.users.Products;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.util.HashMap;

public class AdminUpdateProductsActivity extends AppCompatActivity {
    private EditText inputProductName,inputProductPrice,inputProductDescription;
    private Button apply,delete;
    private ImageView productImage;
    private DatabaseReference productsref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_update_products);
        inputProductName=(EditText)findViewById(R.id.update_product_name);
        inputProductPrice=(EditText)findViewById(R.id.update_product_price);
        inputProductDescription=(EditText)findViewById(R.id.update_product_description);

        apply=(Button)findViewById(R.id.apply_changes_btn);
        delete=(Button)findViewById(R.id.delete_product_btn);

        productImage=(ImageView)findViewById(R.id.update_product_image);
        final String pid = getIntent().getStringExtra("pid");
        productsref= FirebaseDatabase.getInstance().getReference().child("Products").child(pid);

        getProductDetails();

        apply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check(pid);

            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                productsref.removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Intent intent=new Intent(AdminUpdateProductsActivity.this, AdminHomeActivity.class);
                        startActivity(intent);
                        finish();
                        Toast.makeText(AdminUpdateProductsActivity.this, "Product Deletes successfully", Toast.LENGTH_SHORT).show();

                    }
                });

            }
        });




    }

    private void check(String pid) {
        if(inputProductName.getText().toString() == ""){
            Toast.makeText(this, "please enter valid product name", Toast.LENGTH_SHORT).show();
        }
        else if(inputProductPrice.getText().toString() == ""){
            Toast.makeText(this, "please enter valid product price", Toast.LENGTH_SHORT).show();
        }
        else if(inputProductDescription.getText().toString() == ""){
            Toast.makeText(this, "please enter valid product description", Toast.LENGTH_SHORT).show();
        }
        else{
            updateProducts(pid);
        }
    }

    private void updateProducts(String pid) {
        HashMap<String,Object> productMap=new HashMap<>();
        productMap.put("pid",pid);
        productMap.put("pname",inputProductName.getText().toString());
        productMap.put("description",inputProductDescription.getText().toString());
        productMap.put("price",inputProductPrice.getText().toString());

        productsref.updateChildren(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Intent intent=new Intent(AdminUpdateProductsActivity.this, AdminHomeActivity.class);
                    startActivity(intent);
                    Toast.makeText(AdminUpdateProductsActivity.this, "applied changes successfully", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void getProductDetails() {


        productsref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    Products products=dataSnapshot.getValue(Products.class);

                    inputProductName.setText(products.getPname());
                    inputProductDescription.setText(products.getDescription());
                    inputProductPrice.setText(products.getPrice()+"rs");
                    Picasso.get().load(products.getImage()).into(productImage);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}