package com.example.ishop.users;

public class AdminOrders {
    private String address,city,name,phone,date,time,status,price;

    public AdminOrders() {
    }

    public AdminOrders(String address, String city, String name, String phone, String date, String time, String status, String price) {
        this.address = address;
        this.city = city;
        this.name = name;
        this.phone = phone;
        this.date = date;
        this.time = time;
        this.status = status;
        this.price = price;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}
