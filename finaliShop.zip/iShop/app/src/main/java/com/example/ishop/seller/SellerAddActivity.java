package com.example.ishop.seller;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.ishop.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class SellerAddActivity extends AppCompatActivity {

    private String categoryName,product_name,product_price,product_description,saveCurrentDate,saveCurrentTime,productKey,downloadImageUrl;
    EditText inputPrice,inputDescription,inputProductName;
    ImageView inputProductImage;
    private static final int GALLERYPICK=1;
    private Uri imageUri;
    Button addButton;
    private StorageReference productImageRef;
    private DatabaseReference productRef,sellerRef;
    private ProgressDialog loadingbar;
    private String sName,sEmail,sAddress,sPhone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_add);
        categoryName=getIntent().getExtras().get("category").toString();
        Toast.makeText(this, "welcome to "+categoryName, Toast.LENGTH_SHORT).show();
        inputPrice=(EditText)findViewById(R.id.poduct_price);
        inputDescription=(EditText)findViewById(R.id.poduct_description);
        inputProductName=(EditText)findViewById(R.id.poduct_name);
        productImageRef= FirebaseStorage.getInstance().getReference().child("product image");
        productRef=FirebaseDatabase.getInstance().getReference().child("Products");
        sellerRef=FirebaseDatabase.getInstance().getReference().child("Seller");
        loadingbar =new ProgressDialog(this);
        inputProductImage=(ImageView)findViewById(R.id.select_product_image);
        addButton=(Button)findViewById(R.id.addButton);
        inputProductImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openGallery();
            }
        });
        addButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validateProduct();
            }
        });



    }

    private void validateProduct() {
        product_name=inputProductName.getText().toString();
        product_description=inputDescription.getText().toString();
        product_price=inputPrice.getText().toString();

        if(imageUri==null){
            Toast.makeText(this, "please select image", Toast.LENGTH_SHORT).show();

        }
        else if(TextUtils.isEmpty(product_name)){
            Toast.makeText(this, "please enter product name", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(product_price)){
            Toast.makeText(this, "please enter product price", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(product_description)){
            Toast.makeText(this, "please enter product description", Toast.LENGTH_SHORT).show();
        }
        else{
            storeProductInfo();
        }

    }

    private void storeProductInfo() {
        loadingbar.setTitle("Add product");
        loadingbar.setMessage("please Wait");
        loadingbar.setCanceledOnTouchOutside(false);
        loadingbar.show();
        Calendar calendar=Calendar.getInstance();
        SimpleDateFormat currentDate= new SimpleDateFormat("MM dd,yyyy");
        saveCurrentDate=currentDate.format(calendar.getTime());
        SimpleDateFormat currentTime= new SimpleDateFormat("HH:mm:ss a");
        saveCurrentTime=currentTime.format(calendar.getTime());

        productKey=saveCurrentDate+saveCurrentTime;

        final StorageReference filePath=productImageRef.child(imageUri.getLastPathSegment()+productKey);
        final UploadTask uploadTask=filePath.putFile(imageUri);

        uploadTask.addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                String message=e.toString();
                Toast.makeText(SellerAddActivity.this, "Error:"+message, Toast.LENGTH_SHORT).show();
                loadingbar.dismiss();
            }
        }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                Toast.makeText(SellerAddActivity.this, "Image uploaded Successfully", Toast.LENGTH_SHORT).show();

                Task<Uri> urlTask=uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if(!task.isSuccessful()){
                            throw task.getException();
                        }
                        downloadImageUrl=filePath.getDownloadUrl().toString();
                        return filePath.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if(task.isSuccessful()){
                            downloadImageUrl=task.getResult().toString();
                            Toast.makeText(SellerAddActivity.this, "image uploaded successfully", Toast.LENGTH_SHORT).show();
                            saveProductInfoToDatabase();
                        }
                    }
                });
                sellerRef.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if(dataSnapshot!=null){
                            sName=dataSnapshot.child("name").getValue().toString();
                            sPhone=dataSnapshot.child("phone").getValue().toString();
                            sEmail=dataSnapshot.child("email").getValue().toString();
                            sAddress=dataSnapshot.child("address").getValue().toString();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });


            }
        });

    }

    private void saveProductInfoToDatabase() {
        HashMap<String,Object> productMap=new HashMap<>();
        productMap.put("pid",productKey);
        productMap.put("pname",product_name);
        productMap.put("description",product_description);
        productMap.put("price",product_price);
        productMap.put("category",categoryName);
        productMap.put("image",downloadImageUrl);
        productMap.put("date",saveCurrentDate);
        productMap.put("time",saveCurrentTime);
        productMap.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
        productMap.put("productState","Not Approved");
        productMap.put("sName",sName);
        productMap.put("sPhone",sPhone);
        productMap.put("sAddress",sAddress);
        productMap.put("sEmail",sEmail);


        productRef.child(productKey).updateChildren(productMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){

                    Intent intent =new Intent(SellerAddActivity.this, SellerHomeActivity.class);
                    startActivity(intent);
                    finish();
                    Toast.makeText(SellerAddActivity.this, "upload successfull", Toast.LENGTH_SHORT).show();
                    loadingbar.dismiss();
                }
                else{
                    String msg=task.getException().toString();
                    Toast.makeText(SellerAddActivity.this, "Error"+msg, Toast.LENGTH_SHORT).show();
                    loadingbar.dismiss();
                }
            }
        });

    }

    private void openGallery() {
        Intent galleryIntent=new Intent();
        galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
        galleryIntent.setType("image/*");
        startActivityForResult(galleryIntent,GALLERYPICK);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==GALLERYPICK && resultCode==RESULT_OK && data!=null){
            imageUri=data.getData();
            inputProductImage.setImageURI(imageUri);
        }
    }
}