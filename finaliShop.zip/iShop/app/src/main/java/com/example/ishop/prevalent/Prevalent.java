package com.example.ishop.prevalent;

import com.example.ishop.users.Users;

public class Prevalent {
    public static Users currentOnlineUser;

    public  static final String UserPhone="userphone";
    public  static final String UserPass="userpass";


}
