package com.example.ishop.viewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ishop.Interface.ItemClickListner;
import com.example.ishop.R;

public class ProductViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView txtProductName,txtProductDescription,txtProductPrice;
    public ImageView imageView;
    ItemClickListner listner;
    public ProductViewHolder(@NonNull View itemView)
    {
        super(itemView);
        imageView=(ImageView)itemView.findViewById(R.id.image_product);
        txtProductDescription=(TextView)itemView.findViewById(R.id.description_product);
        txtProductName=(TextView)itemView.findViewById(R.id.product_name);
        txtProductPrice=(TextView)itemView.findViewById(R.id.price_product);

    }
    public void setItemClickListner(ItemClickListner listner){
        this.listner=listner;
    }

    @Override
    public void onClick(View view)
    {
      listner.onClick(view,getAdapterPosition(),false);
    }
}
