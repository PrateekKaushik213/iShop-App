package com.example.ishop.viewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ishop.Interface.ItemClickListner;
import com.example.ishop.R;

public class ItemViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView txtProductName,txtProductDescription,txtProductPrice,txtProductState;
    public ImageView imageView;
    ItemClickListner listner;
    public ItemViewHolder(@NonNull View itemView)
    {
        super(itemView);
        imageView=(ImageView)itemView.findViewById(R.id.item_product_image);
        txtProductDescription=(TextView)itemView.findViewById(R.id.item_product_description);
        txtProductName=(TextView)itemView.findViewById(R.id.item_product_name);
        txtProductPrice=(TextView)itemView.findViewById(R.id.item_product_price);
        txtProductState=(TextView)itemView.findViewById(R.id.item_product_state);

    }
    public void setItemClickListner(ItemClickListner listner){
        this.listner=listner;
    }

    @Override
    public void onClick(View view)
    {
        listner.onClick(view,getAdapterPosition(),false);
    }
}
