package com.example.ishop.buyer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishop.R;
import com.example.ishop.seller.SellerHomeActivity;
import com.example.ishop.seller.SellerRegistrationActivity;
import com.example.ishop.prevalent.Prevalent;
import com.example.ishop.users.Users;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import io.paperdb.Paper;

public class MainActivity extends AppCompatActivity {
    Button already,new_user;
    private TextView txtSeller;
    private ProgressDialog loadingbar;
    private String dbname="Users";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        loadingbar=new ProgressDialog(this);
        already=(Button)findViewById(R.id.already);
        new_user=(Button)findViewById(R.id.new_user);
        txtSeller=(TextView)findViewById(R.id.seller_text);

        txtSeller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent intent=new Intent(MainActivity.this, SellerRegistrationActivity.class);
               startActivity(intent);
            }
        });

        already.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this, login.class);
                startActivity(intent);
            }
        });
        new_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this, Register.class);
                startActivity(intent);
            }
        });
        Paper.init(this);
        String userPhone=Paper.book().read(Prevalent.UserPhone);
        String userPass=Paper.book().read(Prevalent.UserPass);
        if(userPhone!=""&& userPass!=""){
            if(!TextUtils.isEmpty(userPhone)&&!TextUtils.isEmpty(userPass)){

                loadingbar.setTitle("already logged in");
                loadingbar.setMessage("please wait. Checking credentials ");
                loadingbar.setCanceledOnTouchOutside(false);
                loadingbar.show();
                allowAccess(userPhone,userPass);

            }
        }

    }

    @Override
    protected void onStart() {
        FirebaseUser user=FirebaseAuth.getInstance().getCurrentUser();
        if(user !=null){
            Intent intent=new Intent(MainActivity.this, SellerHomeActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        }

        super.onStart();
    }

    private void allowAccess(final String userPhone, final String userPass) {
        final DatabaseReference ref;
        ref= FirebaseDatabase.getInstance().getReference();
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.child(dbname).child(userPhone).exists()){
                    Users userData=dataSnapshot.child(dbname).child(userPhone).getValue(Users.class);
                    if(userData.getPhone().equals(userPhone)){
                        if(userData.getPassword().equals(userPass)){
                            Toast.makeText(MainActivity.this, "logged in successfully", Toast.LENGTH_SHORT).show();
                            loadingbar.dismiss();
                            Intent intent=new Intent(MainActivity.this, HomeActivity.class);
                            Prevalent.currentOnlineUser=userData;
                            startActivity(intent);
                        }
                    }
                    else{
                        loadingbar.dismiss();
                        Toast.makeText(MainActivity.this, "login failed", Toast.LENGTH_SHORT).show();

                    }

                }
                else{
                    Toast.makeText(MainActivity.this, "account doesnt exist", Toast.LENGTH_SHORT).show();
                    loadingbar.dismiss();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}