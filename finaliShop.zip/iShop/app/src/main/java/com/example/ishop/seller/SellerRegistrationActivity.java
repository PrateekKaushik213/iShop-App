package com.example.ishop.seller;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ishop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class SellerRegistrationActivity extends AppCompatActivity {
    private EditText inputName,inputPassword,inputPhone,inputEmail,inputAddress;
    private Button register,login;
    private FirebaseAuth mAuth;
    private ProgressDialog loadingbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_registration);
        inputAddress=(EditText)findViewById(R.id.seller_reg_address);
        inputPhone=(EditText)findViewById(R.id.seller_reg_phone);
        inputPassword=(EditText)findViewById(R.id.seller_reg_password);
        inputEmail=(EditText)findViewById(R.id.seller_reg_email);
        inputName=(EditText)findViewById(R.id.seller_reg_name);
        login=(Button)findViewById(R.id.seller_log_btn);
        register=(Button)findViewById(R.id.seller_reg_btn);
        mAuth=FirebaseAuth.getInstance();
        loadingbar=new ProgressDialog(this);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerRegistrationActivity.this, SellerLoginActivity.class);
                startActivity(intent);
            }
        });
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                registerSeller();
            }
        });



    }

    private void registerSeller() {
        final String name=inputName.getText().toString();
        final String phone=inputPhone.getText().toString();
        final String password=inputPassword.getText().toString();
        final String email=inputEmail.getText().toString();
        final String address=inputAddress.getText().toString();

        final DatabaseReference ref= FirebaseDatabase.getInstance().getReference().child("Seller");

        if(!name.equals("") && !phone.equals("") && !password.equals("") && !email.equals("") && !address.equals("")){
            loadingbar.setTitle("Registring account");
            loadingbar.setMessage("please wait.... ");
            loadingbar.setCanceledOnTouchOutside(false);
            loadingbar.show();
            mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                       String uid = mAuth.getCurrentUser().getUid();
                        HashMap<String,Object> map= new HashMap<>();
                        map.put("name",name);
                        map.put("phone",phone);
                        map.put("password",password);
                        map.put("email",email);
                        map.put("address",address);
                        ref.child(uid).updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if(task.isSuccessful()){
                                    loadingbar.dismiss();
                                    Intent intent=new Intent(SellerRegistrationActivity.this, SellerHomeActivity.class);
                                    startActivity(intent);
                                    Toast.makeText(SellerRegistrationActivity.this, "Registration successfully", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                    }
                }
            });

        }
        else {
            Toast.makeText(this, "Please fill the form", Toast.LENGTH_SHORT).show();
        }

    }
}