package com.example.ishop.users;

public class Cart {
    private String discount,pid,price,productName,quantity;

    public Cart() {

    }

    public Cart(String discount, String pid, String price, String productName, String quantity) {
        this.discount = discount;
        this.pid = pid;
        this.price = price;
        this.productName = productName;
        this.quantity = quantity;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }
}
