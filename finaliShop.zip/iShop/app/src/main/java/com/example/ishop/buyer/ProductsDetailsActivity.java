package com.example.ishop.buyer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.cepheuen.elegantnumberbutton.view.ElegantNumberButton;
import com.example.ishop.R;
import com.example.ishop.prevalent.Prevalent;
import com.example.ishop.users.Products;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class ProductsDetailsActivity extends AppCompatActivity {
    private TextView productName,productDescription,productPrice;
    private ImageView productImage;
    private Button addToCart;
    private ElegantNumberButton numberButton;
    private String pid="";
    private String state="normal";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products_details);
        productName = (TextView) findViewById(R.id.product_name_details);
        productDescription = (TextView) findViewById(R.id.poduct_description_details);
        productPrice = (TextView) findViewById(R.id.poduct_price_details);
        productImage = (ImageView) findViewById(R.id.image_details);
        addToCart = (Button) findViewById(R.id.add_to_cart);
        numberButton = (ElegantNumberButton) findViewById(R.id.elegantNumberButton);

        pid = getIntent().getStringExtra("pid");

        getProductDetails(pid);

        addToCart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(state.equals("Order Shipped")||state.equals("Order Placed")){
                    Toast.makeText(ProductsDetailsActivity.this, "please wait once your previous order has been delivered", Toast.LENGTH_SHORT).show();
                }
                else{
                    addingToCartList();
                }

            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        checkStatus();
    }

    private void addingToCartList(){
        Calendar calendar=Calendar.getInstance();
        SimpleDateFormat currentDate=new SimpleDateFormat("MM dd,yyyy");
        String saveCurrentDate=currentDate.format(calendar.getTime());

        SimpleDateFormat currentTime=new SimpleDateFormat("HH:mm:ss a");
        String saveCurrentTime=currentTime.format(calendar.getTime());

        final DatabaseReference cartRef =FirebaseDatabase.getInstance().getReference().child("Cart List");

        final HashMap<String,Object> map=new HashMap<String, Object>();
        map.put("pid",pid);
        map.put("productName",productName.getText().toString());
        map.put("price",productPrice.getText().toString());
        map.put("date",saveCurrentDate);
        map.put("time",saveCurrentTime);
        map.put("quantity",numberButton.getNumber());
        map.put("discount","");

        cartRef.child("User View").child(Prevalent.currentOnlineUser.getPhone()).child("Products").
                child(pid).updateChildren(map)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            cartRef.child("Admin View").child(Prevalent.currentOnlineUser.getPhone()).child("Products").
                                    child(pid).updateChildren(map).
                                    addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()){
                                                Toast.makeText(ProductsDetailsActivity.this, "Product Added to cart", Toast.LENGTH_SHORT).show();
                                                Intent intent=new Intent(ProductsDetailsActivity.this, HomeActivity.class);
                                                startActivity(intent);
                                            }

                                        }
                                    });
                        }

                    }
                });


        }





    private void getProductDetails(String pid) {
        final DatabaseReference productsref= FirebaseDatabase.getInstance().getReference().child("Products");

        productsref.child(pid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    Products products=dataSnapshot.getValue(Products.class);

                    productName.setText(products.getPname());
                    productDescription.setText((products.getDescription()));
                    productPrice.setText(products.getPrice());
                    Picasso.get().load(products.getImage()).into(productImage);

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    private void checkStatus(){
        DatabaseReference orderRef =FirebaseDatabase.getInstance().getReference().child("Orders").child(Prevalent.currentOnlineUser.getPhone());

        orderRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists()){
                    String status =dataSnapshot.child("status").getValue().toString();

                    if(status.equals("shipped")){
                       state="Order Shipped";

                    }
                    else if(status.equals("not shipped")){
                        state="Order Placed";


                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

}