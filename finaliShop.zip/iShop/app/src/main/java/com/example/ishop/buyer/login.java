package com.example.ishop.buyer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishop.R;
import com.example.ishop.admin.AdminHomeActivity;
import com.example.ishop.seller.SellerCategoryActivity;
import com.example.ishop.prevalent.Prevalent;
import com.example.ishop.users.Users;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import io.paperdb.Paper;

public class login extends AppCompatActivity {
    private EditText phone ,password;
    private Button loginbutton;
    private ProgressDialog loadingbar;
    private String dbname="Users";
    private CheckBox checkBox;
    private TextView admin,not_admin,forgetPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);
        phone=(EditText)findViewById(R.id.login_phone);
        password=(EditText)findViewById(R.id.login_password);
        loginbutton=(Button)findViewById(R.id.login_button);
        loadingbar=new ProgressDialog(this);
        checkBox=(CheckBox)findViewById(R.id.checkBox);
        admin=(TextView)findViewById(R.id.admin);
        not_admin=(TextView)findViewById(R.id.not_admin);
        forgetPassword=(TextView)findViewById(R.id.forget_password);

        forgetPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(login.this, ResetPasswordActivity.class);
                intent.putExtra("check","login");
                startActivity(intent);
            }
        });


        admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginbutton.setText("Login as admin");
                admin.setVisibility(View.INVISIBLE);
                not_admin.setVisibility(View.VISIBLE);
                dbname="Admins";
            }
        });
        not_admin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginbutton.setText("Login");
                admin.setVisibility(View.VISIBLE);
                not_admin.setVisibility(View.INVISIBLE);
                dbname="Users";
            }
        });


        Paper.init(this);
        loginbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginValidate();

            }
        });

    }

    private void loginValidate() {
        String phnNo=phone.getText().toString();
        String pass=password.getText().toString();
        if(TextUtils.isEmpty(phnNo)){
            Toast.makeText(this, "please enter phone no", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(pass)){
            Toast.makeText(this, "please enter password", Toast.LENGTH_SHORT).show();
        }
        else{
            loadingbar.setTitle("Login account");
            loadingbar.setMessage("please wait. Checking credentials ");
            loadingbar.setCanceledOnTouchOutside(false);
            loadingbar.show();
            userValidate(phnNo,pass);
        }
    }

    private void userValidate(final String phnNo, final String pass) {

        if(checkBox.isChecked()){
            Paper.book().write(Prevalent.UserPass,pass);
            Paper.book().write(Prevalent.UserPhone,phnNo);
        }


        final DatabaseReference ref;


        ref= FirebaseDatabase.getInstance().getReference();
        ref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               if(dataSnapshot.child(dbname).child(phnNo).exists()){
                   Users userData=dataSnapshot.child(dbname).child(phnNo).getValue(Users.class);
                   if(userData.getPhone().equals(phnNo)){
                       if(userData.getPassword().equals(pass)){
                           if(dbname.equals("Users")){
                               Toast.makeText(login.this, "logged in successfully", Toast.LENGTH_SHORT).show();
                               loadingbar.dismiss();
                               Intent intent=new Intent(login.this, HomeActivity.class);
                               Prevalent.currentOnlineUser =userData;
                               startActivity(intent);
                           }
                           else if(dbname.equals("Admins")){
                               Toast.makeText(login.this, "logged in successfully as an admin", Toast.LENGTH_SHORT).show();
                               loadingbar.dismiss();
                               Intent intent=new Intent(login.this, AdminHomeActivity.class);
                               startActivity(intent);
                           }
                       }
                   }
                   else{
                       loadingbar.dismiss();
                       Toast.makeText(login.this, "login failed", Toast.LENGTH_SHORT).show();

                   }

               }
               else{
                   Toast.makeText(login.this, "account doesnt exist", Toast.LENGTH_SHORT).show();
                   loadingbar.dismiss();
               }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
}