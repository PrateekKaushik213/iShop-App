package com.example.ishop.buyer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ishop.R;
import com.example.ishop.prevalent.Prevalent;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class ConfirmOrderActivity extends AppCompatActivity {
    private EditText txtName,txtPhone,txtAddress,txtCity;
    private Button confirmButton;
    private String totalPrice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_order);
        txtName=(EditText)findViewById(R.id.shipment_name);
        txtPhone=(EditText)findViewById(R.id.shipment_phone);
        txtAddress=(EditText)findViewById(R.id.shipment_address);
        txtCity=(EditText)findViewById(R.id.shipment_city);
        confirmButton=(Button)findViewById(R.id.shipment_button);
        totalPrice=getIntent().getStringExtra("price");
        Toast.makeText(this, "amount:"+totalPrice, Toast.LENGTH_SHORT).show();

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check();
            }
        });



    }

    private void check() {
        if(TextUtils.isEmpty(txtName.getText().toString())){
            Toast.makeText(this, "please enter name", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(txtPhone.getText().toString())){
            Toast.makeText(this, "please enter phone", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(txtAddress.getText().toString())){
            Toast.makeText(this, "please enter address", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(txtCity.getText().toString())){
            Toast.makeText(this, "please enter city", Toast.LENGTH_SHORT).show();
        }
        else{
            placeOrder();
        }
    }

    private void placeOrder() {
        Calendar calendar=Calendar.getInstance();
        SimpleDateFormat currentDate=new SimpleDateFormat("MM dd,yyyy");
        String saveCurrentDate=currentDate.format(calendar.getTime());

        SimpleDateFormat currentTime=new SimpleDateFormat("HH:mm:ss a");
        String saveCurrentTime=currentTime.format(calendar.getTime());

        DatabaseReference orderRef= FirebaseDatabase.getInstance().getReference().child("Orders").child(Prevalent.currentOnlineUser.getPhone());
        final HashMap<String,Object> map=new HashMap<String, Object>();
        map.put("phone",txtPhone.getText().toString());
        map.put("name",txtName.getText().toString());
        map.put("price",totalPrice);
        map.put("date",saveCurrentDate);
        map.put("time",saveCurrentTime);
        map.put("address",txtAddress.getText().toString());
        map.put("city",txtCity.getText().toString());
        map.put("status","not shipped");

        orderRef.updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    FirebaseDatabase.getInstance().getReference().child("Cart List")
                            .child("User View").child(Prevalent.currentOnlineUser.getPhone())
                            .removeValue()
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if(task.isSuccessful()){
                                        Toast.makeText(ConfirmOrderActivity.this, "order is successfully placed", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(ConfirmOrderActivity.this, HomeActivity.class);
                                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                                        startActivity(intent);
                                        finish();
                                    }
                                }
                            });
                }
            }
        });

    }

}