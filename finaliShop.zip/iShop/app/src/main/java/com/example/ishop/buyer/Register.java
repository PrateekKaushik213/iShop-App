package com.example.ishop.buyer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ishop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Register extends AppCompatActivity {
    Button reg_button;
    EditText name,phone,password;
    ProgressDialog loadingbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        reg_button=(Button)findViewById(R.id.reg_button);
        name=(EditText)findViewById(R.id.username);
        phone=(EditText)findViewById(R.id.reg_phn);
        password=(EditText)findViewById(R.id.reg_password);
        loadingbar=new ProgressDialog(this);

        reg_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                validate();
            }
        });
    }

    private void validate() {
        String user=name.getText().toString();
        String number=phone.getText().toString();
        String pass=password.getText().toString();

        if(TextUtils.isEmpty(user)){
            Toast.makeText(this, "please enter isername", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(number)){
            Toast.makeText(this, "please enter isername", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(pass)){
            Toast.makeText(this, "please enter isername", Toast.LENGTH_SHORT).show();
        }
        else {
            loadingbar.setTitle("Create account");
            loadingbar.setMessage("please wait checking credentials");
            loadingbar.setCanceledOnTouchOutside(false);
            loadingbar.show();
            validateNo(user,number,pass);

        }

    }

    private void validateNo(final String user, final String number, final String pass) {
        final DatabaseReference Rootref;
        Rootref= FirebaseDatabase.getInstance().getReference();
        Rootref.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(!dataSnapshot.child("Users").child(number).exists()){
                    HashMap<String,Object> dataMap=new HashMap<>();
                    dataMap.put("name",user);
                    dataMap.put("phone",number);
                    dataMap.put("password",pass);
                    Rootref.child("Users").child(number).updateChildren(dataMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if(task.isSuccessful()){
                                Toast.makeText(Register.this, "reg is successful", Toast.LENGTH_SHORT).show();
                                loadingbar.dismiss();
                                Intent intent=new Intent(Register.this, login.class);
                                startActivity(intent);
                            }
                            else{
                                loadingbar.dismiss();
                                Toast.makeText(Register.this, "network issue PLease try again later", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
                else {
                    Toast.makeText(Register.this, "this no is already exist", Toast.LENGTH_SHORT).show();
                    loadingbar.dismiss();
                    Toast.makeText(Register.this, "try again with diffrent no", Toast.LENGTH_SHORT).show();
                    Intent intent=new Intent(Register.this,login.class);
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

}