package com.example.ishop.admin;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.example.ishop.R;
import com.example.ishop.users.AdminOrders;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AdminNewOrderActivity extends AppCompatActivity {
    private RecyclerView orderList;
    private DatabaseReference orderRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_new_order);

        orderList=(RecyclerView)findViewById(R.id.orders_recycler_view);
        orderList.setLayoutManager(new LinearLayoutManager(this));

        orderRef= FirebaseDatabase.getInstance().getReference().child("Orders");
    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseRecyclerOptions<AdminOrders> options =new FirebaseRecyclerOptions.Builder<AdminOrders>()
                .setQuery(orderRef,AdminOrders.class)
                .build();

        FirebaseRecyclerAdapter<AdminOrders,AdminOrderViewHolder> adapter =new FirebaseRecyclerAdapter<AdminOrders, AdminOrderViewHolder>(options) {
            @Override
            protected void onBindViewHolder(@NonNull AdminOrderViewHolder holder, final int position, @NonNull final AdminOrders model) {

                holder.txtname.setText("Name: "+model.getName());
                holder.txtphone.setText("Phone: "+model.getPhone());
                holder.txtprice.setText("Total Price: "+model.getPrice());
                holder.txtaddress.setText("Shipping Address: "+model.getAddress());
                holder.txtdate.setText("Order At "+model.getDate()+" "+model.getTime());
                holder.orderButton.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {

                        String uid=getRef(position).getKey();
                        Intent intent=new Intent(AdminNewOrderActivity.this, AdminProductsActivity.class);
                        intent.putExtra("userId",uid);
                        startActivity(intent);
                    }
                });
                holder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        CharSequence options[]=new CharSequence[]{
                                "Yes","No"
                        };
                        AlertDialog.Builder dialog=new AlertDialog.Builder(AdminNewOrderActivity.this);
                        dialog.setTitle("Have you shipped the order");
                        dialog.setItems(options, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                if(i==0){
                                    String uid=getRef(position).getKey();
                                    removeOrder(uid);
                                }
                                else{
                                    finish();
                                }

                            }
                        });
                        dialog.show();
                    }
                });



            }

            @NonNull
            @Override
            public AdminOrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.orders_layout,parent,false);
                return new AdminOrderViewHolder(view);
            }
        };
        orderList.setAdapter(adapter);
        adapter.startListening();

    }

    private void removeOrder(String uid) {
        orderRef.child(uid).removeValue();
    }

    public static class AdminOrderViewHolder extends RecyclerView.ViewHolder {

        public TextView txtname,txtphone,txtprice,txtaddress,txtdate;
        public Button orderButton;
        public AdminOrderViewHolder(@NonNull View itemView) {
            super(itemView);

            txtname=itemView.findViewById(R.id.order_user_name);
            txtphone=itemView.findViewById(R.id.order_phone_number);
            txtprice=itemView.findViewById(R.id.order_price);
            txtaddress=itemView.findViewById(R.id.order_address);
            txtdate=itemView.findViewById(R.id.order_date);

            orderButton=itemView.findViewById(R.id.order_items);


        }
    }
}