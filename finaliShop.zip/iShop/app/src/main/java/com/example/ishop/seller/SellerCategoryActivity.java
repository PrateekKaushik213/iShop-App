package com.example.ishop.seller;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.example.ishop.R;

public class SellerCategoryActivity extends AppCompatActivity {
    ImageView tshirts,female_dresses,sweater,sports;
    ImageView glasses,hats,purses_bags,shoes;
    ImageView headphones,laptops,mobiles,watches;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_category);
        tshirts=(ImageView)findViewById(R.id.tshirts);
        female_dresses=(ImageView)findViewById(R.id.female_dresses);
        sweater=(ImageView)findViewById(R.id.sweather);
        sports=(ImageView)findViewById(R.id.sports);
        glasses=(ImageView)findViewById(R.id.glasses);
        hats=(ImageView)findViewById(R.id.hats);
        purses_bags=(ImageView)findViewById(R.id.purses_bags);
        shoes=(ImageView)findViewById(R.id.shoess);
        headphones=(ImageView)findViewById(R.id.headphoness);
        laptops=(ImageView)findViewById(R.id.laptops);
        mobiles=(ImageView)findViewById(R.id.mobiles);
        watches=(ImageView)findViewById(R.id.watches);




        tshirts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","tshirts");
                startActivity(intent);
            }
        });
        female_dresses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","female dresses");
                startActivity(intent);
            }
        });
        sweater.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Sweater");
                startActivity(intent);
            }
        });
        sports.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Sports");
                startActivity(intent);
            }
        });
        glasses.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","glasses");
                startActivity(intent);
            }
        });
        hats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Hats");
                startActivity(intent);
            }
        });
        purses_bags.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Purses and Bags");
                startActivity(intent);
            }
        });
        shoes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Shoes");
                startActivity(intent);
            }
        });
        headphones.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Headphones");
                startActivity(intent);
            }
        });
        laptops.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Laptops");
                startActivity(intent);
            }
        });
        mobiles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Mobiles");
                startActivity(intent);
            }
        });
        watches.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SellerCategoryActivity.this, SellerAddActivity.class);
                intent.putExtra("category","Watches");
                startActivity(intent);
            }
        });
    }
}