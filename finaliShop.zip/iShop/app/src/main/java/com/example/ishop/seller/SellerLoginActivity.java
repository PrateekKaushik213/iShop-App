package com.example.ishop.seller;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.ishop.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class SellerLoginActivity extends AppCompatActivity {
    private EditText inputEmail,inputPassword;
    private Button login;
    private FirebaseAuth mAuth;
    private ProgressDialog loadingbar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_login);
        inputPassword=(EditText)findViewById(R.id.seller_login_password);
        inputEmail=(EditText)findViewById(R.id.seller_login_email);
        login=(Button)findViewById(R.id.seller_login);
        mAuth= FirebaseAuth.getInstance();
        loadingbar=new ProgressDialog(this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginSeller();
            }
        });
    }

    private void loginSeller() {
        final String password=inputPassword.getText().toString();
        final String email=inputEmail.getText().toString();

        if( !password.equals("") && !email.equals("")){
            loadingbar.setTitle("Login account");
            loadingbar.setMessage("please wait. Checking credentials ");
            loadingbar.setCanceledOnTouchOutside(false);
            loadingbar.show();
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        loadingbar.dismiss();
                        Intent intent=new Intent(SellerLoginActivity.this, SellerHomeActivity.class);
                        startActivity(intent);
                        Toast.makeText(SellerLoginActivity.this, "login success", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }
        else{
            Toast.makeText(this, "please fill details", Toast.LENGTH_SHORT).show();
        }
    }
}