package com.example.ishop.admin;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.ishop.R;
import com.example.ishop.buyer.HomeActivity;
import com.example.ishop.buyer.MainActivity;
import com.example.ishop.seller.SellerCategoryActivity;

public class AdminHomeActivity extends AppCompatActivity {
    private Button logout,order,updateProducts,approve;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);
        logout=(Button)findViewById(R.id.admin_logout);
        order=(Button)findViewById(R.id.new_order);
        updateProducts=(Button)findViewById(R.id.update_products);
        approve=(Button)findViewById(R.id.approve_product);

        updateProducts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(AdminHomeActivity.this, HomeActivity.class);
                intent.putExtra("Admin","Admin");
                startActivity(intent);
            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(AdminHomeActivity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK |Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
        order.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(AdminHomeActivity.this, AdminNewOrderActivity.class);
                startActivity(intent);
            }
        });
        approve.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(AdminHomeActivity.this, ApproveProductsActivity.class);
                startActivity(intent);
            }
        });

    }
}