package com.example.ishop.buyer;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.ishop.R;
import com.example.ishop.prevalent.Prevalent;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class ResetPasswordActivity extends AppCompatActivity {
    private TextView txtResetPassword,txtResetAnswer;
    private EditText inputPhone,inputAnswer1,inputAnswer2;
    private Button verifyButton;
    private String check="";
    private DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reset_password);
        txtResetPassword=(TextView)findViewById(R.id.reset_password);
        txtResetAnswer=(TextView)findViewById(R.id.reset_answer_text);
        inputPhone=(EditText)findViewById(R.id.reset_phone);
        inputAnswer1=(EditText)findViewById(R.id.reset_answer_one);
        inputAnswer2=(EditText)findViewById(R.id.reset_answer_two);
        verifyButton=(Button)findViewById(R.id.reset_verify_btn);
        check=getIntent().getExtras().get("check").toString();
        ref= FirebaseDatabase.getInstance().getReference().child("Users");

         if(check.equals("setting")){
             txtResetPassword.setText("Set anwers");
             verifyButton.setText("Set");
             txtResetAnswer.setText("Answer the below question ");
             inputPhone.setVisibility(View.GONE);
             verifyButton.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View view) {
                     String answer1=inputAnswer1.getText().toString().toLowerCase();
                     String answer2=inputAnswer2.getText().toString().toLowerCase();
                     if(TextUtils.isEmpty(answer1)){
                         Toast.makeText(ResetPasswordActivity.this, "please give answer one", Toast.LENGTH_SHORT).show();
                     }
                     else if(TextUtils.isEmpty(answer2)){
                         Toast.makeText(ResetPasswordActivity.this, "please give answer two", Toast.LENGTH_SHORT).show();
                     }
                     else{
                         setQuestion(answer1,answer2);
                     }

                 }
             });
         }
         else if(check.equals("login")){
             verifyButton.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View view) {
                     String phone=inputPhone.getText().toString();
                     String answer1=inputAnswer1.getText().toString().toLowerCase();
                     String answer2=inputAnswer2.getText().toString().toLowerCase();
                     if(TextUtils.isEmpty(phone)){
                         Toast.makeText(ResetPasswordActivity.this, "please enter phone number", Toast.LENGTH_SHORT).show();
                     }
                     else if(TextUtils.isEmpty(answer1)){
                         Toast.makeText(ResetPasswordActivity.this, "please give answer one", Toast.LENGTH_SHORT).show();
                     }
                     else if(TextUtils.isEmpty(answer2)){
                         Toast.makeText(ResetPasswordActivity.this, "please give answer two", Toast.LENGTH_SHORT).show();
                     }
                     else{
                         verifyQuestion(phone,answer1,answer2);
                     }

                 }
             });
         }



    }

    private void verifyQuestion(final String phone, final String answer1, final String answer2) {

        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists() && dataSnapshot.hasChild(phone)){
                    String ans1=dataSnapshot.child(phone).child("Security question").child("answer1").getValue().toString().toLowerCase();
                    String ans2=dataSnapshot.child(phone).child("Security question").child("answer2").getValue().toString().toLowerCase();
                    if (!ans1.equals(answer1)) {
                        Toast.makeText(ResetPasswordActivity.this, "answer 1 doesnt match", Toast.LENGTH_SHORT).show();
                    }
                    else if (!ans2.equals(answer2)) {
                        Toast.makeText(ResetPasswordActivity.this, "answer 2 doesnt match", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        AlertDialog.Builder builder=new AlertDialog.Builder(ResetPasswordActivity.this);
                        builder.setTitle("New Password");
                        final EditText text=new EditText(ResetPasswordActivity.this);
                        text.setHint("write new password");
                        builder.setView(text);

                        builder.setPositiveButton("change", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, final int i) {
                                if(!text.getText().toString().equals("")){
                                    ref.child(phone).child("password").setValue(text.getText().toString())
                                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                                @Override
                                                public void onComplete(@NonNull Task<Void> task) {
                                                    if(task.isSuccessful()){
                                                        Intent intent =new Intent(ResetPasswordActivity.this, login.class);
                                                        startActivity(intent);
                                                        finish();
                                                        Toast.makeText(ResetPasswordActivity.this, "password changed successfully", Toast.LENGTH_SHORT).show();
                                                    }
                                                }
                                            });
                                }
                            }

                        });
                        builder.show();
                    }
                }
                else {
                    Toast.makeText(ResetPasswordActivity.this, "phone no not exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void setQuestion(String answer1, String answer2) {
        HashMap<String,Object> map=new HashMap<>();
        map.put("answer1",answer1);
        map.put("answer2",answer2);
        ref.child(Prevalent.currentOnlineUser.getPhone()).child("Security question").updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Intent intent=new Intent(ResetPasswordActivity.this, SettingActivity.class);
                    startActivity(intent);
                    finish();
                    Toast.makeText(ResetPasswordActivity.this, "success", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }


}